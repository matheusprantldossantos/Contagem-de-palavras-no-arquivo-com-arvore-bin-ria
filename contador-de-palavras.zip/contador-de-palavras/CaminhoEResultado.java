public class CaminhoEResultado {
    public String caminho;
    public int resultado;

    public CaminhoEResultado(String caminho, int resultado) {
        this.caminho = caminho;
        this.resultado = resultado;
    }
}