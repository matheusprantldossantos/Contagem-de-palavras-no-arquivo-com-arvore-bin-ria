public class Main {
    private static void insereEImprimeFormatado(ArvoreAVL arvoreAVL, int valor) {
        arvoreAVL.insere_elemento(valor);  
        System.out.format("+%3d | ", valor);  
        arvoreAVL.imprime_preordem();  
    }

    private static void removeEImprimeFormatado(ArvoreAVL arvoreAVL, int valor) {  
        arvoreAVL.remove_elemento(valor); 
        System.out.format("-%3d | ", valor);  
        arvoreAVL.imprime_preordem(); 
    }


    
    public static void main(String[] args) { 
        int[][] valoresDeTeste = { { 77, 55, 76, 56, 33, 36, 44, 67, 16, 88 },
                { 40, 51, 27, 1, 89, 84, 97, 70, 35, 14 },
                { 19, 34, 31, 3, 80, 92, 66, 29, 52, 26 },
                { 32, 25, 13, 57, 12, 58, 100, 68, 99, 63 }, 
                { 18, 47, 42, 37, 38, 79, 21, 64, 7, 2 } };  

        ArvoreAVL arvoreAVL = new ArvoreAVL();   
        ArvoreAVL arvoreParaRemocao = new ArvoreAVL(); 


        for (int i = 0; i < valoresDeTeste.length; ++i) {
            System.out.println("Teste " + (i + 1));   
            for (int j = 0; j < valoresDeTeste[i].length; ++j) {  
                insereEImprimeFormatado(arvoreAVL, valoresDeTeste[i][j]); 
            }
            arvoreAVL.esvazia(); 
            System.out.println(); 
        }



        System.out.println("Teste de remocao na arvore do Teste 5"); 
        for (int i = 0; i < valoresDeTeste[4].length; ++i) {  
            arvoreParaRemocao.insere_elemento(valoresDeTeste[4][i]); 
            System.out.format("+%3d | ", valoresDeTeste[4][i]); 
            arvoreParaRemocao.imprime_preordem(); 
        }
        removeEImprimeFormatado(arvoreParaRemocao, 47); 
        removeEImprimeFormatado(arvoreParaRemocao, 79);
        removeEImprimeFormatado(arvoreParaRemocao, 64);
        removeEImprimeFormatado(arvoreParaRemocao, 2);
        removeEImprimeFormatado(arvoreParaRemocao, 20);
        removeEImprimeFormatado(arvoreParaRemocao, 38);
    }
}