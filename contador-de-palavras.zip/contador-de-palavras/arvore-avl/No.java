public class No {
    public int valor;
    public int altura;
    public No esquerda;
    public No direita;

    No(int valor) {
        this.valor = valor;
        altura = 0;
        esquerda = null;
        direita = null;
    }
}